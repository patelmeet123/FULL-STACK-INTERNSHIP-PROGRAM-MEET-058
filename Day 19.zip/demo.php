<html>
    <body>
        <?php
        echo"meet patel";
        ?>
        </body>
        </html>
        