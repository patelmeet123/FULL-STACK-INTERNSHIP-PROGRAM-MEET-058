<!DOCTYPE html>
<html>
<body>

<?php
$x = 100;  
$y = "100";

echo var_dump($x == $y)."<br>";
echo var_dump($x === $y)."<br>";
echo var_dump($x != $y)."<br>";
echo var_dump($x <> $y)."<br>";
echo var_dump($x !== $y)."<br>";
echo var_dump($x <= $y)."<br>";
?>  

</body>
</html>