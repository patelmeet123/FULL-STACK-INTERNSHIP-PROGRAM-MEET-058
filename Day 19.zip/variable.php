<!DOCTYPE html>
<html>
    <body>
        <?php
        $txt="Hello World";
        $x=10;
        $y=5;
        echo $txt;
echo "<br>";
echo $x;
echo "<br>";
echo $y;
?>

</body>
</html>
