<!DOCTYPE html>
<html>
    <body>
        <?php
        $x=5;
        $y=2;
       
        echo ($x + $y)."<br>";
        echo ($x - $y)."<br>";
        echo ($x % $y)."<br>";
        echo ($x * $y)."<br>";
        echo ($x / $y)."<br>";
        ?>
    </body>
</html>